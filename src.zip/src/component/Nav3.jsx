import React from 'react'
import '../style/navbars.css'
function Nav3() {
  return (
    <div className="nav3">
        <ul>
            <li><select name="" id="">
                <option value="">JEWLLERY</option></select></li>
            <li><select name="" id="">
                <option value="">Gold</option>
            </select></li>
            <li>
                <select name="" id="">
                    <option value="">Diamond</option>
                </select>
            </li>
            <li>SOLITARE</li>
            <li>SILVER</li>
            <li>pLATINUM</li>
            <li>GOLD COIN</li>
            <li>
                <select name="" id="">
                    <option value="">More</option>
                </select>
            </li>
        </ul>
    </div>
  )
}

export default Nav3