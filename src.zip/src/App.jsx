import logo from './logo.svg';
import './App.css';
import Nav1 from './component/Nav1';
import Nav2 from './component/Nav2';
import Nav3 from './component/Nav3';


function App() {
  return (
  <>
  <Nav1 />
  <Nav2/>
  <Nav3 />
  </>
  );
}

export default App;
